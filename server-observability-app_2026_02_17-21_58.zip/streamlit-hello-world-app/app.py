import os
import re
from typing import List, Optional, Dict, Any

import pandas as pd
import streamlit as st

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import sql as dbsql


st.set_page_config(page_title="Server Observability Dashboard", layout="wide")

st.markdown(
    """
<style>
.recommendations h1 { font-size: 1.6rem !important; }
.recommendations h2 { font-size: 1.35rem !important; }
.recommendations h3 { font-size: 1.15rem !important; }
.recommendations h4 { font-size: 1.05rem !important; }
.recommendations p { margin-bottom: 0.4rem; }
.recommendations ul { margin-bottom: 0.6rem; }

.block-container { padding-top: 2.0rem; padding-bottom: 2.0rem; }
h1 { margin-bottom: 0.5rem; }
[data-testid="stMetricValue"] { font-size: 2.2rem; }
div[data-testid="stDataFrame"] thead tr th { background: rgba(0,0,0,0.03); }
label { font-size: 0.9rem !important; }
</style>
""",
    unsafe_allow_html=True,
)

st.title("Server Observability Dashboard")


@st.cache_resource
def get_workspace_client():
    return WorkspaceClient()


w = get_workspace_client()

WAREHOUSE_ID = os.getenv("DATABRICKS_WAREHOUSE_ID", "").strip() or "47bde9279fec4222"
CATALOG = os.getenv("OBS_CATALOG", "").strip() or "btris_dbx"
SCHEMA = os.getenv("OBS_SCHEMA", "").strip() or "observability"
SERVERS_VIEW = os.getenv("OBS_SERVERS_VIEW", "").strip() or "v_servers"
PERF_TABLE = os.getenv("OBS_PERF_TABLE", "").strip() or "perfmon_metrics_delta"
EVENTS_TABLE = os.getenv("OBS_EVENTS_TABLE", "").strip() or "windows_events_delta"

ENDPOINT = (os.environ.get("TRIENNIAL_ENDPOINT") or "databricks-meta-llama-3-3-70b-instruct").strip()


def _safe_float(x) -> Optional[float]:
    try:
        if x is None:
            return None
        return float(x)
    except Exception:
        return None


def _build_context(
    *,
    server: str,
    cpu_val: Optional[float],
    mem_val: Optional[float],
    cache_hit_val: Optional[float],
    top_waits_df: Optional[pd.DataFrame],
    meq_df: Optional[pd.DataFrame],
    max_waits: int = 5,
    max_queries: int = 10,
) -> Dict[str, Any]:
    waits_preview: List[Dict[str, Any]] = []
    if isinstance(top_waits_df, pd.DataFrame) and not top_waits_df.empty:
        cols = [c for c in ["wait_type", "total_wait_ms", "samples"] if c in top_waits_df.columns]
        waits_preview = top_waits_df[cols].head(max_waits).to_dict(orient="records")

    meq_preview: List[Dict[str, Any]] = []
    if isinstance(meq_df, pd.DataFrame) and not meq_df.empty:
        df = meq_df.copy()
        df = df.reset_index(drop=False).rename(columns={"index": "row"})
        cols = [c for c in ["row", "cpu_query", "physical_reads_query", "cpu_query_url", "physical_reads_query_url", "jobs_url", "datetime"] if c in df.columns]
        meq_preview = df[cols].head(max_queries).to_dict(orient="records")

    return {
        "server": server,
        "snapshot": {
            "max_cpu_utilization_pct": _safe_float(cpu_val),
            "max_memory_utilization_pct": _safe_float(mem_val),
            "cache_hit_ratio_pct": _safe_float(cache_hit_val),
        },
        "top_waits": waits_preview,
        "most_expensive_queries": meq_preview,
    }


def _invoke_llm(endpoint_name: str, system_msg: str, user_msg: str, *, temperature: float, max_tokens: int) -> str:
    body = {
        "messages": [
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg},
        ],
        "temperature": float(temperature),
        "max_tokens": int(max_tokens),
    }

    try:
        resp = w.api_client.do("POST", f"/serving-endpoints/{endpoint_name}/invocations", body=body)
    except Exception as e:
        raise RuntimeError(f"LLM endpoint call failed: {e}")

    content: Optional[str] = None
    if isinstance(resp, dict):
        choices = resp.get("choices")
        if isinstance(choices, list) and choices:
            c0 = choices[0] if isinstance(choices[0], dict) else {}
            msg = c0.get("message") if isinstance(c0, dict) else None
            if isinstance(msg, dict):
                content = msg.get("content")
            if content is None and isinstance(c0, dict):
                content = c0.get("text")
        if content is None:
            preds = resp.get("predictions")
            if isinstance(preds, list) and preds:
                if isinstance(preds[0], str):
                    content = preds[0]

    if not content or not isinstance(content, str):
        raise RuntimeError("LLM returned an unexpected response shape (no text content).")

    return content.strip()


def _strip_numbered_heading_hashes(md_text: str) -> str:
    lines = md_text.splitlines()
    out = []
    for ln in lines:
        m = re.match(r"^\s*#{1,6}\s*(\d+\))\s*(.*)$", ln)
        if m:
            out.append(f"{m.group(1)} {m.group(2)}".rstrip())
        else:
            out.append(ln)
    return "\n".join(out).strip()


def generate_llm_recommendations(
    endpoint_name: str,
    *,
    server: str,
    cpu_val: Optional[float],
    mem_val: Optional[float],
    cache_hit_val: Optional[float],
    top_waits_df: Optional[pd.DataFrame],
    meq_df: Optional[pd.DataFrame],
) -> str:
    context = _build_context(
        server=server,
        cpu_val=cpu_val,
        mem_val=mem_val,
        cache_hit_val=cache_hit_val,
        top_waits_df=top_waits_df,
        meq_df=meq_df,
    )

    system_msg = (
        "You are a senior SQL Server performance engineer (Windows + OLTP workloads). "
        "You must produce detailed, actionable recommendations strictly grounded in the provided telemetry JSON. "
        "Do NOT invent data (plans, indexes, DMVs results, wait causes) that are not present. "
        "When data is missing, explicitly say what to collect and provide the exact query/steps to collect it."
    )

    user_msg = f"""
You are given:
- Server snapshot: CPU%, Memory%, Cache hit ratio% (may be null)
- Top waits summary (may be empty)
- Most expensive query samples (by CPU and Physical Reads), possibly truncated

Deliver a performance review with this EXACT structure in Markdown (do NOT use Markdown heading hashes like #, ##, ###):

1) Executive diagnosis (3–6 bullets)

2) Query-level recommendations (repeat for EACH query sample)
For each query sample, include:
- Query row number (from most_expensive_queries[].row)
- Query label: CPU or Physical Reads
- What makes it expensive (evidence-based; if insufficient data, say so)
- What to collect next (exact SQL Server commands/DMVs)
- Concrete tuning actions (ordered, 6–12 items)

3) Server-level recommendations (8–14 bullets; only if supported by snapshot/waits)

4) Prioritized action plan
Create a table with columns: Priority | Action | Expected Impact | Effort | How to Validate

Telemetry (JSON):
{context}
""".strip()

    text = _invoke_llm(endpoint_name, system_msg, user_msg, temperature=0.15, max_tokens=1400)
    return _strip_numbered_heading_hashes(text)


def ask_llm_about_queries(
    endpoint_name: str,
    *,
    server: str,
    cpu_val: Optional[float],
    mem_val: Optional[float],
    cache_hit_val: Optional[float],
    top_waits_df: Optional[pd.DataFrame],
    meq_df: Optional[pd.DataFrame],
    question: str,
) -> str:
    context = _build_context(
        server=server,
        cpu_val=cpu_val,
        mem_val=mem_val,
        cache_hit_val=cache_hit_val,
        top_waits_df=top_waits_df,
        meq_df=meq_df,
    )

    system_msg = (
        "You are a senior SQL Server performance engineer. "
        "Answer ONLY using the telemetry JSON. "
        "If the user asks for something not supported by the telemetry (e.g., exact execution plan operators), "
        "say it is not available and propose the precise next data to collect (with exact commands)."
    )

    user_msg = f"""
User question (may reference query row numbers from the table): {question}

Constraints:
- If the question references row numbers, map them to most_expensive_queries[].row and answer about those rows.
- If the question asks 'which query is worst', compare ONLY using what is present (query snippet presence, whether CPU vs Physical Reads field is populated, etc.).
- Provide a crisp answer, then a short 'Next data to collect' list with exact SQL Server commands.

Telemetry (JSON):
{context}
""".strip()

    text = _invoke_llm(endpoint_name, system_msg, user_msg, temperature=0.2, max_tokens=700)
    return _strip_numbered_heading_hashes(text)


def q_ident(name: str) -> str:
    if name is None:
        return ""
    return f"`{name.replace('`', '``')}`"


def fqtn(catalog: str, schema: str, obj: str) -> str:
    return f"{q_ident(catalog)}.{q_ident(schema)}.{q_ident(obj)}"


@st.cache_data(ttl=60)
def run_query(query: str) -> pd.DataFrame:
    try:
        resp = w.statement_execution.execute_statement(
            warehouse_id=WAREHOUSE_ID,
            statement=query,
            wait_timeout="30s",
        )

        state = resp.status.state if resp.status else None

        if state in (dbsql.StatementState.PENDING, dbsql.StatementState.RUNNING):
            return pd.DataFrame()

        if state != dbsql.StatementState.SUCCEEDED:
            err_msg = None
            err_code = None
            if resp.status and resp.status.error:
                err_msg = getattr(resp.status.error, "message", None) or str(resp.status.error)
                err_code = getattr(resp.status.error, "error_code", None)
            raise RuntimeError(f"State={state} Code={err_code} Error={err_msg}")

        rows = resp.result.data_array if (resp.result and resp.result.data_array) else []

        cols: List[str] = []
        if resp.manifest and resp.manifest.schema and resp.manifest.schema.columns:
            cols = [c.name for c in resp.manifest.schema.columns]

        if not cols:
            if rows:
                cols = [f"col_{i+1}" for i in range(len(rows[0]))]
            else:
                return pd.DataFrame()

        return pd.DataFrame(rows, columns=cols)

    except Exception as e:
        st.error(f"Query failed. {e}")
        return pd.DataFrame()


@st.cache_data(ttl=300)
def get_table_columns(catalog: str, schema: str, table: str) -> List[str]:
    info_schema = f"{q_ident(catalog)}.information_schema.columns"
    q = f"""
    SELECT column_name
    FROM {info_schema}
    WHERE table_schema = '{schema}'
      AND table_name = '{table}'
    ORDER BY ordinal_position
    """
    df = run_query(q)
    if df.empty or "column_name" not in df.columns:
        return []
    return df["column_name"].dropna().astype(str).tolist()


def pick_first_existing(existing: List[str], candidates: List[str]) -> Optional[str]:
    lower_map = {c.lower(): c for c in existing}
    for cand in candidates:
        key = cand.lower()
        if key in lower_map:
            return lower_map[key]
    return None


def must_pick(existing: List[str], key: str, mapping: Dict[str, List[str]]) -> Optional[str]:
    return pick_first_existing(existing, mapping.get(key, []))


PERF_COLS: Dict[str, List[str]] = {
    "datetime": ["datetime", "date_time", "timestamp", "time", "dt", "Datetime", "DateTime"],
    "server_name": ["server_name", "servername", "server", "machine", "machine_name", "server name", "Server Name", "MachineName"],
    "max_cpu_utilization": ["max_cpu_utilization", "max_cpu", "cpu_max", "max_cpu_util", "max CPU utilization", "Max CPU utilization"],
    "max_memory_utilization": ["max_memory_utilization", "max_memory", "memory_max", "max_mem_util", "max Memory Utilization", "Max Memory Utilization"],
    "wait_type": ["wait_type", "waittype", "Wait type", "WAIT TYPE", "wait type"],
    "wait_time_ms": [
        "wait_timems",
        "wait_time_ms",
        "wait_time",
        "wait_times",
        "waittime_ms",
        "wait_time_milliseconds",
        "Wait time(ms)",
        "WAIT TIME(MS)",
        "wait time(ms)",
        "Wait time(ms) ",
        "Wait time (ms)",
        "wait time (ms)",
    ],
    "cache_hit_ratio": ["cache_hit_ratio", "cach_hit_ratio", "cache_hit", "cach_hit", "Cach Hit Ratio", "Cache Hit Ratio"],
    "most_expensive_query_by_cpu": ["most_expensive_query_by_cpu", "Most expensive query by cpu"],
    "most_expensive_query_by_cpu_url": ["most_expensive_query_by_cpu_url", "Most expensive query by cpu  URL", "Most expensive query by cpu URL"],
    "most_expensive_query_by_physical_reads": ["most_expensive_query_by_physical_reads", "Most expensive query by physical reads"],
    "most_expensive_query_by_physical_reads_url": ["most_expensive_query_by_physical_reads_url", "Most expensive query by physical reads URL"],
    "jobsurl": ["jobsurl", "jobs_url", "JobsURL", "Jobs Url", "Jobs URL"],
}

EVENTS_COLS: Dict[str, List[str]] = {
    "server_name": ["server_name", "machinename", "machine_name", "server"],
    "time_created": ["time_created", "timecreated", "time_created_utc"],
    "level": ["LevelDisplayName", "leveldisplayname", "level", "severity"],
    "provider": ["ProviderName", "providername", "provider"],
    "id": ["ID", "id", "event_id"],
    "message": ["Message", "message", "msg"],
}


servers_df = run_query(f"""
SELECT DISTINCT server_name
FROM {fqtn(CATALOG, SCHEMA, SERVERS_VIEW)}
ORDER BY server_name
""")

if servers_df.empty or "server_name" not in servers_df.columns:
    st.warning("No servers found (or the query failed).")
    st.stop()

server_list = servers_df["server_name"].dropna().astype(str).tolist()

col_search, col_select, col_spacer = st.columns([1.2, 1.8, 3])

with col_search:
    search_text = st.text_input("Search Server", placeholder="Type to filter...")

filtered_servers = [s for s in server_list if search_text.lower() in s.lower()] if search_text else server_list

with col_select:
    selected_server = st.selectbox("Select Server", filtered_servers, label_visibility="visible")

perf_cols = get_table_columns(CATALOG, SCHEMA, PERF_TABLE)
if not perf_cols:
    st.warning(f"Could not read columns for {CATALOG}.{SCHEMA}.{PERF_TABLE}.")
    st.stop()

perf_dt = must_pick(perf_cols, "datetime", PERF_COLS)
perf_srv = must_pick(perf_cols, "server_name", PERF_COLS)
cpu_col = must_pick(perf_cols, "max_cpu_utilization", PERF_COLS)
mem_col = must_pick(perf_cols, "max_memory_utilization", PERF_COLS)
wait_type_col = must_pick(perf_cols, "wait_type", PERF_COLS)
wait_time_col = must_pick(perf_cols, "wait_time_ms", PERF_COLS)
cache_hit_col = must_pick(perf_cols, "cache_hit_ratio", PERF_COLS)

if not perf_srv or not perf_dt:
    st.error("Perf table is missing required keys (server_name and/or datetime).")
    st.stop()


def latest_single_value(col_name: Optional[str], alias: str) -> Optional[float]:
    if not col_name:
        return None
    df = run_query(f"""
    SELECT {q_ident(col_name)} AS {alias}
    FROM {fqtn(CATALOG, SCHEMA, PERF_TABLE)}
    WHERE {q_ident(perf_srv)} = '{selected_server}'
    ORDER BY {q_ident(perf_dt)} DESC
    LIMIT 1
    """)
    if df.empty or alias not in df.columns:
        return None
    return pd.to_numeric(df[alias], errors="coerce").iloc[0]


cpu_val = latest_single_value(cpu_col, "cpu")
mem_val = latest_single_value(mem_col, "mem")
cache_val = latest_single_value(cache_hit_col, "cache_hit") if cache_hit_col else None

tabs = st.tabs(["Overview", "Windows Events", "Most Expensive Queries"])


with tabs[0]:
    k1, k2, k3, k4 = st.columns([1, 1, 1, 1])
    with k1:
        st.metric("Max CPU Utilization", value=f"{cpu_val:.0f}%" if pd.notna(cpu_val) else "N/A")
    with k2:
        st.metric("Max Memory Utilization", value=f"{mem_val:.0f}%" if pd.notna(mem_val) else "N/A")
    with k3:
        st.metric("Cache Hit Ratio", value=f"{cache_val:.0f}%" if (cache_hit_col and pd.notna(cache_val)) else "N/A")
    with k4:
        st.metric("Selected Server", value=selected_server)

    st.divider()

    left, right = st.columns([1.1, 1.4], gap="large")

    with left:
        st.subheader("I/O Stats")
        st.info("I/O fields are not present in the provided perfmon CSV. Add disk metrics columns and I’ll wire this block.")

    with right:
        st.subheader("Waits breakdown")

        missing = []
        if not wait_type_col:
            missing.append("wait_type")
        if not wait_time_col:
            missing.append("wait_time_ms")

        if missing:
            st.warning("Missing wait columns: " + ", ".join(missing))
        else:
            waits_df = run_query(f"""
            SELECT
              {q_ident(wait_type_col)} AS wait_type,
              SUM(CAST({q_ident(wait_time_col)} AS DOUBLE)) AS total_wait_ms,
              COUNT(*) AS samples
            FROM {fqtn(CATALOG, SCHEMA, PERF_TABLE)}
            WHERE {q_ident(perf_srv)} = '{selected_server}'
            GROUP BY {q_ident(wait_type_col)}
            ORDER BY total_wait_ms DESC
            LIMIT 10
            """)
            n_rows = int(waits_df.shape[0]) if isinstance(waits_df, pd.DataFrame) else 0
            table_height = min(10, max(1, n_rows)) * 35 + 38
            st.dataframe(waits_df, use_container_width=True, height=table_height)


with tabs[1]:
    st.subheader("Windows Events")

    ev_cols = get_table_columns(CATALOG, SCHEMA, EVENTS_TABLE)
    if not ev_cols:
        st.warning(f"Could not read columns for {CATALOG}.{SCHEMA}.{EVENTS_TABLE}.")
    else:
        ev_srv = must_pick(ev_cols, "server_name", EVENTS_COLS)
        ev_time = must_pick(ev_cols, "time_created", EVENTS_COLS)
        ev_lvl = must_pick(ev_cols, "level", EVENTS_COLS)
        ev_prov = must_pick(ev_cols, "provider", EVENTS_COLS)
        ev_id = must_pick(ev_cols, "id", EVENTS_COLS)
        ev_msg = must_pick(ev_cols, "message", EVENTS_COLS)

        if not (ev_srv and ev_time):
            st.warning("Events table missing required keys (server_name / time_created).")
        else:
            c1, c2, c3 = st.columns([1.2, 1.2, 2.6])
            with c1:
                level_filter = st.multiselect(
                    "Level",
                    options=["Critical", "Error", "Warning", "Information"],
                    default=[],
                    help="Optional filter. Leave empty to show all levels.",
                )
            with c2:
                max_rows = st.selectbox("Rows", options=[25, 50, 100, 200], index=0)

            where_bits = [f"{q_ident(ev_srv)} = '{selected_server}'"]
            if level_filter and ev_lvl:
                levels_sql = ", ".join([f"'{x}'" for x in level_filter])
                where_bits.append(f"{q_ident(ev_lvl)} IN ({levels_sql})")

            where_sql = " AND ".join(where_bits)

            select_bits = [f"{q_ident(ev_time)} AS time_created"]
            if ev_lvl:
                select_bits.append(f"{q_ident(ev_lvl)} AS level")
            if ev_prov:
                select_bits.append(f"{q_ident(ev_prov)} AS provider")
            if ev_id:
                select_bits.append(f"{q_ident(ev_id)} AS id")
            if ev_msg:
                select_bits.append(f"{q_ident(ev_msg)} AS message")

            events_df = run_query(f"""
            SELECT {", ".join(select_bits)}
            FROM {fqtn(CATALOG, SCHEMA, EVENTS_TABLE)}
            WHERE {where_sql}
            ORDER BY {q_ident(ev_time)} DESC
            LIMIT {int(max_rows)}
            """)
            n_rows = int(events_df.shape[0]) if isinstance(events_df, pd.DataFrame) else 0
            table_height = min(18, max(6, n_rows)) * 35 + 38
            st.dataframe(events_df, use_container_width=True, height=table_height)


with tabs[2]:
    st.subheader("Most Expensive Queries")

    cpu_q_col = must_pick(perf_cols, "most_expensive_query_by_cpu", PERF_COLS)
    cpu_u_col = must_pick(perf_cols, "most_expensive_query_by_cpu_url", PERF_COLS)
    phy_q_col = must_pick(perf_cols, "most_expensive_query_by_physical_reads", PERF_COLS)
    phy_u_col = must_pick(perf_cols, "most_expensive_query_by_physical_reads_url", PERF_COLS)
    jobs_col = must_pick(perf_cols, "jobsurl", PERF_COLS)

    select_q = []
    if cpu_q_col:
        select_q.append(f"{q_ident(cpu_q_col)} AS cpu_query")
    if cpu_u_col:
        select_q.append(f"{q_ident(cpu_u_col)} AS cpu_query_url")
    if phy_q_col:
        select_q.append(f"{q_ident(phy_q_col)} AS physical_reads_query")
    if phy_u_col:
        select_q.append(f"{q_ident(phy_u_col)} AS physical_reads_query_url")
    if jobs_col:
        select_q.append(f"{q_ident(jobs_col)} AS jobs_url")
    select_q.append(f"{q_ident(perf_dt)} AS datetime")

    meq_df: Optional[pd.DataFrame] = None
    if select_q:
        meq_df = run_query(f"""
        SELECT {", ".join(select_q)}
        FROM {fqtn(CATALOG, SCHEMA, PERF_TABLE)}
        WHERE {q_ident(perf_srv)} = '{selected_server}'
        ORDER BY {q_ident(perf_dt)} DESC
        LIMIT 10
        """)
        n_rows = int(meq_df.shape[0]) if isinstance(meq_df, pd.DataFrame) else 0
        table_height = min(12, max(1, n_rows)) * 35 + 38
        st.dataframe(meq_df, use_container_width=True, height=table_height)
    else:
        st.info("No expensive-query columns found in perf table.")

    st.divider()

    top_waits_df: Optional[pd.DataFrame] = None
    if wait_type_col and wait_time_col:
        top_waits_df = run_query(f"""
        SELECT
          {q_ident(wait_type_col)} AS wait_type,
          SUM(CAST({q_ident(wait_time_col)} AS DOUBLE)) AS total_wait_ms,
          COUNT(*) AS samples
        FROM {fqtn(CATALOG, SCHEMA, PERF_TABLE)}
        WHERE {q_ident(perf_srv)} = '{selected_server}'
        GROUP BY {q_ident(wait_type_col)}
        ORDER BY total_wait_ms DESC
        LIMIT 5
        """)

    if "meq_reco_text" not in st.session_state:
        st.session_state["meq_reco_text"] = ""
    if "meq_qa_mode" not in st.session_state:
        st.session_state["meq_qa_mode"] = False
    if "meq_qa_answer" not in st.session_state:
        st.session_state["meq_qa_answer"] = ""

    btn_c1, btn_c2, _ = st.columns([1.6, 1.8, 3.6])
    with btn_c1:
        gen_clicked = st.button("Generate recommendations", use_container_width=True)
    with btn_c2:
        ask_clicked = st.button("Ask about these queries", use_container_width=True)

    if ask_clicked:
        st.session_state["meq_qa_mode"] = True
        st.session_state["meq_qa_answer"] = ""

    if gen_clicked:
        st.session_state["meq_qa_mode"] = False
        st.session_state["meq_qa_answer"] = ""
        if not isinstance(meq_df, pd.DataFrame) or meq_df.empty:
            st.info("No expensive-query rows found for the selected server, so LLM recommendations cannot be generated.")
        else:
            with st.spinner("Generating recommendations from LLM..."):
                st.session_state["meq_reco_text"] = generate_llm_recommendations(
                    ENDPOINT,
                    server=selected_server,
                    cpu_val=cpu_val,
                    mem_val=mem_val,
                    cache_hit_val=cache_val,
                    top_waits_df=top_waits_df,
                    meq_df=meq_df,
                )

    if st.session_state["meq_qa_mode"]:
        st.subheader("Ask the LLM about the most expensive queries")
        st.caption(f"LLM endpoint: {ENDPOINT}")
        st.caption("Tip: refer to rows by their number in the table (0, 1, 2, ...).")

        q = st.text_area("Your question", placeholder="Example: For row 0, what should I collect next to prove why it is expensive?")

        qa_c1, qa_c2, _ = st.columns([1.2, 1.2, 4.6])
        with qa_c1:
            submit_q = st.button("Ask LLM", use_container_width=True)
        with qa_c2:
            clear_q = st.button("Clear answer", use_container_width=True)

        if clear_q:
            st.session_state["meq_qa_answer"] = ""

        if submit_q:
            if not q.strip():
                st.warning("Please enter a question.")
            elif not isinstance(meq_df, pd.DataFrame) or meq_df.empty:
                st.info("No expensive-query rows found for the selected server.")
            else:
                with st.spinner("Thinking..."):
                    st.session_state["meq_qa_answer"] = ask_llm_about_queries(
                        ENDPOINT,
                        server=selected_server,
                        cpu_val=cpu_val,
                        mem_val=mem_val,
                        cache_hit_val=cache_val,
                        top_waits_df=top_waits_df,
                        meq_df=meq_df,
                        question=q.strip(),
                    )

        if st.session_state["meq_qa_answer"]:
            st.markdown("### Answer (LLM)")
            st.markdown(st.session_state["meq_qa_answer"])

    else:
        st.subheader("Recommendations")
        st.caption(f"LLM endpoint: {ENDPOINT}")

        if st.session_state["meq_reco_text"]:
            st.markdown("### Generated recommendations (LLM)")
            try:
                import markdown as md  # type: ignore

                html = md.markdown(st.session_state["meq_reco_text"], extensions=["tables", "fenced_code"])
                st.markdown(f'<div class="recommendations">{html}</div>', unsafe_allow_html=True)
            except Exception:
                st.markdown(st.session_state["meq_reco_text"])
        else:
            st.info("Click **Generate recommendations** to run the LLM for the currently displayed most expensive queries.")
